import allEventDefs from '../allEventDefs';

export type EventType = keyof typeof allEventDefs;
