export const TEAM_IDS = [1, 2];
