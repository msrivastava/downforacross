export const hashGridRow = (row: any, misc: object) => JSON.stringify([row, misc]);
